package models

// ChatwootUser representa o usuário do Chatwoot
type ChatwootUser struct {
	UserType string
	UserID   int
}

